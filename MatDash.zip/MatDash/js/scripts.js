document.addEventListener('DOMContentLoaded', () => {
    console.log("Сайт загружен. Можно добавить больше интерактива.");
});
