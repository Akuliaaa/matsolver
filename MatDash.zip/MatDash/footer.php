</main>
<footer class="footer">
    <div class="footer-content">
        <p>&copy; <?= date('Y') ?> MathSolver. Все права защищены.</p>
        <p><a href="mailto:support@mathsolver.local">support@mathsolver.local</a> | <a href="/MatDash/privacy.php">Политика конфиденциальности</a></p>
    </div>
</footer>
</body>
</html>
